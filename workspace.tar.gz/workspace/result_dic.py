results_dic = dict()

items_in_dic = len(results_dic)
print("\nEmpty Dictionary results_dic - n items=", iteam_in_dic)

filenames = 
